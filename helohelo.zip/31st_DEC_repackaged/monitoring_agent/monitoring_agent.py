import pyshark
import requests
import logging
import time

# Configuration
SERVER_URL = 'http://localhost:5000/traffic'
INTERFACE = 'Wi-Fi'  # Adjust as needed for the user's system

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def capture_and_send_traffic():
    """
    Captures live network traffic and sends data to the backend server continuously.
    """
    try:
        logging.info(f"Starting traffic capture on interface: {INTERFACE}")
        capture = pyshark.LiveCapture(interface=INTERFACE)

        for packet in capture.sniff_continuously():
            try:
                # Extract key details from the packet
                traffic_data = {
                    'timestamp': packet.sniff_time.isoformat(),
                    'source_ip': packet.ip.src,
                    'destination_ip': packet.ip.dst,
                    'protocol': packet.transport_layer,
                    'length': packet.length
                }

                # Send the data to the server
                response = requests.post(SERVER_URL, json=traffic_data)
                if response.status_code == 200:
                    logging.info("Traffic data sent successfully.")
                else:
                    logging.warning(f"Failed to send data: {response.status_code} - {response.text}")

            except AttributeError as e:
                # Skip packets that don't have the required attributes
                logging.debug(f"Packet skipped due to missing attributes: {e}")

    except Exception as e:
        logging.error(f"Error during traffic capture: {e}")
        time.sleep(5)  # Retry after a short delay

if __name__ == '__main__':
    while True:
        capture_and_send_traffic()
