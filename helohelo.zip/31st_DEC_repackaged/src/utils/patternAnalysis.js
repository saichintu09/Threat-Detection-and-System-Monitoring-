export const analyzePattern = (data, pattern) => {
  const stringData = typeof data === 'object' ? JSON.stringify(data) : String(data);
  return pattern.test(stringData);
};

export const calculateThreatLevel = (threats) => {
  const weights = {
    ransomware: 0.9,
    shellcode: 0.8,
    injection: 0.7,
    malware: 0.6
  };

  return threats.reduce((score, threat) => {
    return score + (weights[threat.malwareType] || 0.5);
  }, 0);
};