export const TERMINAL_COLORS = {
  info: '\x1b[32m',    // Green
  warning: '\x1b[33m', // Yellow
  error: '\x1b[31m',   // Red
  reset: '\x1b[0m'     // Reset
};

export const CHART_COLORS = {
  inbound: '#00ff00',
  outbound: '#ff0000',
  text: '#00ff00'
};

export const UPDATE_INTERVALS = {
  network: 1000,
  behavior: 3000
};

export const MAX_DATA_POINTS = 50;