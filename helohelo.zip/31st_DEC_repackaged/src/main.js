import { ProcessMonitor } from './core/ProcessMonitor.js';
import { BehaviorAnalyzer } from './detection/BehaviorAnalyzer.js';
import { SecurityDashboard } from './ui/Dashboard.js';
import { UPDATE_INTERVALS } from './utils/constants.js';
import './styles/main.css';

const initializeApplication = () => {
  const processMonitor = new ProcessMonitor();
  const behaviorAnalyzer = new BehaviorAnalyzer();
  const dashboard = new SecurityDashboard(
    document.getElementById('security-dashboard')
  );

  // Simulate malware behavior
  const simulateBehavior = () => {
    const behaviors = [
      {
        type: 'keylogging',
        pid: 1,
        name: 'keylog.exe',
        data: 'Attempting to access keyboard input stream'
      },
      {
        type: 'encryption',
        pid: 2,
        name: 'ransom.exe',
        data: 'Encrypting user files with .encrypt() method'
      },
      {
        type: 'persistence',
        pid: 3,
        name: 'persist.exe',
        data: 'Modifying startup folder'
      }
    ];

    const behavior = behaviors[Math.floor(Math.random() * behaviors.length)];
    processMonitor.trackProcess(behavior.pid, behavior.name, 'running');
    
    const detections = behaviorAnalyzer.analyzeBehavior(behavior);
    detections.forEach(detection => {
      dashboard.terminal.log(
        `Detected ${detection.name}: ${detection.data}`,
        detection.severity
      );
    });

    dashboard.updateProcessList(processMonitor.processes);
    dashboard.updateBehaviorPatterns(detections);
  };

  // Simulate network traffic
  const simulateNetwork = () => {
    dashboard.updateNetworkTraffic({
      inbound: Math.random() * 1000,
      outbound: Math.random() * 1000,
      timestamp: Date.now()
    });
  };

  // Start simulations
  setInterval(simulateBehavior, UPDATE_INTERVALS.behavior);
  setInterval(simulateNetwork, UPDATE_INTERVALS.network);
};

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', initializeApplication);