class NetworkMonitor {
  constructor(systemMonitor) {
    this.systemMonitor = systemMonitor;
    this.connections = new Map();
    this.startMonitoring();
  }

  startMonitoring() {
    setInterval(() => {
      this.analyzeTraffic();
    }, 3000);
  }

  analyzeTraffic() {
    const traffic = this.simulateTraffic();
    if (this.detectAnomaly(traffic)) {
      this.systemMonitor.notifyListeners({
        type: 'network-anomaly',
        data: traffic,
        timestamp: Date.now()
      });
    }
  }

  simulateTraffic() {
    return {
      inbound: Math.random() * 1000,
      outbound: Math.random() * 1000,
      connections: Math.floor(Math.random() * 100)
    };
  }

  detectAnomaly(traffic) {
    return traffic.inbound > 800 || traffic.outbound > 800;
  }
}

export default NetworkMonitor;