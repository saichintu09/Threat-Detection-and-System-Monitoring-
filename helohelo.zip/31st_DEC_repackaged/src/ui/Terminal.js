import { Terminal } from 'xterm';
import 'xterm/css/xterm.css';

export class SecurityTerminal {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.initialize();
  }

  initialize() {
    this.terminal = new Terminal({
      theme: {
        background: '#000000',
        foreground: '#00ff00',
        cursor: '#00ff00'
      },
      cursorBlink: true,
      rows: 15
    });
    
    this.terminal.open(this.container);
    this.terminal.writeln('Security Monitoring System Terminal initialized...');
  }

  log(message, type = 'info') {
    const timestamp = new Date().toISOString();
    const colorMap = {
      info: '\x1b[32m',    // Green
      warning: '\x1b[33m',  // Yellow
      error: '\x1b[31m',    // Red
      reset: '\x1b[0m'
    };

    const color = colorMap[type] || colorMap.info;
    const formattedMessage = `${color}[${timestamp}] ${message}${colorMap.reset}\r\n`;
    
    this.terminal.writeln(formattedMessage);
  }

  clear() {
    this.terminal.clear();
  }
}