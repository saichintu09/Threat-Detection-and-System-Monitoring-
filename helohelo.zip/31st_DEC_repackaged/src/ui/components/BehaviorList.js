export class BehaviorList {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
  }

  update(patterns) {
    this.container.innerHTML = patterns.map(pattern => `
      <div class="pattern-item ${pattern.severity}">
        <span class="pattern-name">${pattern.name}</span>
        <span class="pattern-time">
          ${new Date(pattern.timestamp).toLocaleTimeString()}
        </span>
      </div>
    `).join('');
  }
}