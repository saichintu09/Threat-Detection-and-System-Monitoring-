export class ProcessList {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
  }

  update(processes) {
    this.container.innerHTML = Array.from(processes).map(([pid, process]) => `
      <div class="process-item ${process.status}">
        <span class="pid">${pid}</span>
        <span class="name">${process.name}</span>
        <span class="status">${process.status}</span>
      </div>
    `).join('');
  }
}