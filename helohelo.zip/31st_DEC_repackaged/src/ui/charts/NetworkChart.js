import { Chart } from 'chart.js/auto';
import { CHART_COLORS, MAX_DATA_POINTS } from '../../utils/constants.js';
import { formatTimestamp } from '../../utils/formatters.js';

export class NetworkChart {
  constructor(canvasId) {
    this.ctx = document.getElementById(canvasId).getContext('2d');
    this.initialize();
  }

  initialize() {
    this.chart = new Chart(this.ctx, {
      type: 'line',
      data: {
        labels: [],
        datasets: [{
          label: 'Inbound Traffic',
          borderColor: CHART_COLORS.inbound,
          data: []
        }, {
          label: 'Outbound Traffic',
          borderColor: CHART_COLORS.outbound,
          data: []
        }]
      },
      options: {
        responsive: true,
        animation: false,
        plugins: {
          legend: {
            labels: {
              color: CHART_COLORS.text
            }
          }
        },
        scales: {
          y: {
            ticks: { color: CHART_COLORS.text }
          },
          x: {
            ticks: { color: CHART_COLORS.text }
          }
        }
      }
    });
  }

  update(data) {
    const { inbound, outbound, timestamp } = data;
    
    this.chart.data.labels.push(formatTimestamp(timestamp));
    this.chart.data.datasets[0].data.push(inbound);
    this.chart.data.datasets[1].data.push(outbound);

    if (this.chart.data.labels.length > MAX_DATA_POINTS) {
      this.chart.data.labels.shift();
      this.chart.data.datasets.forEach(dataset => dataset.data.shift());
    }

    this.chart.update();
  }
}