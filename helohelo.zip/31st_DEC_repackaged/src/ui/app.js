// Frontend JavaScript to integrate WebSocket and display live updates

const socket = io('http://localhost:5000'); // Connect to the WebSocket server

// DOM elements
const trafficList = document.getElementById('traffic-list');

// Function to add a traffic packet to the UI
function addTrafficPacket(packet) {
    const listItem = document.createElement('li');
    listItem.textContent = `Time: ${packet.timestamp}, Source: ${packet.source_ip}, Destination: ${packet.destination_ip}, Protocol: ${packet.protocol}, Length: ${packet.length}`;
    trafficList.appendChild(listItem);
}

// Handle initial data from the server
socket.on('initialData', (data) => {
    trafficList.innerHTML = ''; // Clear existing list
    data.forEach(addTrafficPacket);
});

// Handle new traffic packets in real-time
socket.on('newPacket', (packet) => {
    addTrafficPacket(packet);
});

// Error handling
socket.on('connect_error', (error) => {
    console.error('Connection error:', error);
});
