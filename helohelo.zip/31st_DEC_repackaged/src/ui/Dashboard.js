import { SecurityTerminal } from './Terminal.js';
import { NetworkChart } from './charts/NetworkChart.js';
import { ProcessList } from './components/ProcessList.js';
import { BehaviorList } from './components/BehaviorList.js';

export class SecurityDashboard {
  constructor(container) {
    this.container = container;
    this.initialize();
  }

  initialize() {
    this.createLayout();
    this.initializeComponents();
  }

  createLayout() {
    this.container.innerHTML = `
      <div class="dashboard-grid">
        <div class="dashboard-item">
          <h2>Process Monitor</h2>
          <div id="process-list"></div>
        </div>
        <div class="dashboard-item">
          <h2>Behavior Analysis</h2>
          <div id="behavior-patterns"></div>
        </div>
        <div class="dashboard-item">
          <h2>Network Traffic</h2>
          <canvas id="network-chart"></canvas>
        </div>
        <div class="dashboard-item">
          <h2>Terminal Output</h2>
          <div id="security-terminal"></div>
        </div>
      </div>
    `;
  }

  initializeComponents() {
    this.terminal = new SecurityTerminal('security-terminal');
    this.networkChart = new NetworkChart('network-chart');
    this.processList = new ProcessList('process-list');
    this.behaviorList = new BehaviorList('behavior-patterns');
  }

  updateProcessList(processes) {
    this.processList.update(processes);
  }

  updateBehaviorPatterns(patterns) {
    this.behaviorList.update(patterns);
  }

  updateNetworkTraffic(data) {
    this.networkChart.update(data);
  }
}