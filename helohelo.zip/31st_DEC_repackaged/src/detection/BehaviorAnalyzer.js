export class BehaviorAnalyzer {
  constructor() {
    this.patterns = new Map();
    this.initializePatterns();
  }

  initializePatterns() {
    this.addPattern('keylogging', {
      name: 'Keylogging Pattern',
      indicators: [
        /keyboard.*hook/i,
        /GetAsyncKeyState/i,
        /keyboard.*input.*stream/i
      ],
      severity: 'high'
    });

    this.addPattern('encryption', {
      name: 'File Encryption Pattern',
      indicators: [
        /\.encrypt\(/i,
        /\.decrypt\(/i,
        /crypto.*api/i
      ],
      severity: 'critical'
    });

    this.addPattern('persistence', {
      name: 'Persistence Pattern',
      indicators: [
        /startup.*folder/i,
        /registry.*run/i,
        /scheduled.*task/i
      ],
      severity: 'medium'
    });

    this.addPattern('network', {
      name: 'Network Pattern',
      indicators: [
        /connect.*remote/i,
        /dns.*query/i,
        /http.*request/i
      ],
      severity: 'medium'
    });
  }

  addPattern(type, config) {
    this.patterns.set(type, config);
  }

  analyzeBehavior(data) {
    const detections = [];
    
    for (const [type, config] of this.patterns) {
      const matched = config.indicators.some(pattern => 
        pattern.test(JSON.stringify(data))
      );

      if (matched) {
        detections.push({
          type,
          name: config.name,
          severity: config.severity,
          timestamp: Date.now(),
          data
        });
      }
    }

    return detections;
  }
}