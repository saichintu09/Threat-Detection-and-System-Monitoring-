import { analyzePattern } from '../utils/patternAnalysis.js';

class ThreatDetector {
  constructor(systemMonitor) {
    this.systemMonitor = systemMonitor;
    this.signatures = new Map();
    this.initializeSignatures();
  }

  initializeSignatures() {
    this.addSignature('ransomware', /\.encrypt\(|\.decrypt\(/i);
    this.addSignature('shellcode', /\x90{5,}|\x00{5,}/);
    this.addSignature('injection', /document\.write\(|eval\(|new Function\(/i);
    this.addSignature('malware', /virus|trojan|worm/i);
  }

  addSignature(type, pattern) {
    this.signatures.set(type, pattern);
  }

  analyze(data) {
    const results = Array.from(this.signatures.entries())
      .filter(([type, pattern]) => analyzePattern(data, pattern))
      .map(([type]) => ({
        type: 'malware-detected',
        malwareType: type,
        timestamp: Date.now(),
        data
      }));

    results.forEach(result => this.systemMonitor.notifyListeners(result));
    return results;
  }
}

export default ThreatDetector;