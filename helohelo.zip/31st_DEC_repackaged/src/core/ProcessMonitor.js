export class ProcessMonitor {
  constructor() {
    this.processes = new Map();
    this.listeners = new Set();
  }

  trackProcess(pid, name, status) {
    this.processes.set(pid, { name, status, startTime: Date.now() });
    this.notifyListeners('process-start', { pid, name, status });
  }

  updateProcessStatus(pid, status) {
    const process = this.processes.get(pid);
    if (process) {
      process.status = status;
      this.notifyListeners('process-update', { pid, status });
    }
  }

  terminateProcess(pid) {
    const process = this.processes.get(pid);
    if (process) {
      this.processes.delete(pid);
      this.notifyListeners('process-end', { pid });
    }
  }

  addListener(callback) {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }

  notifyListeners(type, data) {
    this.listeners.forEach(listener => listener({ type, ...data }));
  }
}