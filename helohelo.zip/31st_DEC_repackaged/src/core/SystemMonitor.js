class SystemMonitor {
  constructor() {
    this.activeThreats = new Set();
    this.listeners = new Set();
    this.startRealTimeMonitoring();
  }

  addListener(callback) {
    this.listeners.add(callback);
    return () => this.removeListener(callback);
  }

  removeListener(callback) {
    this.listeners.delete(callback);
  }

  notifyListeners(event) {
    this.listeners.forEach(listener => listener(event));
  }

  startRealTimeMonitoring() {
    setInterval(() => {
      this.checkSystemStatus();
    }, 5000);
  }

  checkSystemStatus() {
    const metrics = {
      cpu: Math.random() * 100,
      memory: Math.random() * 100,
      networkTraffic: Math.random() * 1000
    };
    
    this.notifyListeners({
      type: 'system-metrics',
      data: metrics,
      timestamp: Date.now()
    });
  }
}

export default SystemMonitor;