class SecurityLogger {
  constructor() {
    this.logs = [];
    this.maxLogs = 1000;
  }

  log(event) {
    const logEntry = {
      timestamp: Date.now(),
      severity: this.calculateSeverity(event),
      ...event
    };

    this.logs.unshift(logEntry);
    
    if (this.logs.length > this.maxLogs) {
      this.logs.pop();
    }

    console.log(`[${new Date(logEntry.timestamp).toISOString()}] ${logEntry.severity}: ${JSON.stringify(event)}`);
  }

  calculateSeverity(event) {
    switch (event.type) {
      case 'malware-detected':
        return 'CRITICAL';
      case 'threat-detected':
        return 'HIGH';
      case 'anomaly-detected':
        return 'MEDIUM';
      default:
        return 'LOW';
    }
  }

  getLogs(filter = {}) {
    return this.logs.filter(log => {
      for (const [key, value] of Object.entries(filter)) {
        if (log[key] !== value) return false;
      }
      return true;
    });
  }
}

export default SecurityLogger;