import SystemMonitor from './monitor/SystemMonitor.js';
import ThreatDetector from './detection/ThreatDetector.js';
import MalwareSimulator from './simulation/MalwareSimulator.js';
import SecurityLogger from './logger/SecurityLogger.js';
import SecurityDashboard from './ui/SecurityDashboard.js';

// Initialize the security system
const systemMonitor = new SystemMonitor();
const threatDetector = new ThreatDetector(systemMonitor);
const malwareSimulator = new MalwareSimulator(systemMonitor);
const securityLogger = new SecurityLogger();

// Set up the dashboard
const dashboard = new SecurityDashboard(
  document.getElementById('security-dashboard'),
  systemMonitor,
  securityLogger
);

// Add event listeners
systemMonitor.addListener(event => {
  threatDetector.analyze(event);
});

// Example: Simulate attacks periodically
setInterval(async () => {
  const scenarios = ['ransomware', 'injection'];
  const randomScenario = scenarios[Math.floor(Math.random() * scenarios.length)];
  await malwareSimulator.simulateAttack(randomScenario);
}, 5000);