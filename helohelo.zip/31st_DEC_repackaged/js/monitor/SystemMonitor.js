class SystemMonitor {
  constructor() {
    this.activeThreats = new Set();
    this.listeners = new Set();
  }

  addListener(callback) {
    this.listeners.add(callback);
  }

  removeListener(callback) {
    this.listeners.delete(callback);
  }

  notifyListeners(event) {
    this.listeners.forEach(listener => listener(event));
  }

  detectAnomaly(data) {
    const anomalyScore = this.calculateAnomalyScore(data);
    if (anomalyScore > 0.7) {
      const threat = {
        id: crypto.randomUUID(),
        type: 'anomaly',
        score: anomalyScore,
        timestamp: Date.now(),
        data
      };
      this.activeThreats.add(threat);
      this.notifyListeners({ type: 'threat-detected', threat });
    }
  }

  calculateAnomalyScore(data) {
    // Implement anomaly detection logic here
    // This is a simplified example
    const patterns = [
      /exec\([^)]*\)/i,
      /eval\([^)]*\)/i,
      /base64/i
    ];
    
    let score = 0;
    patterns.forEach(pattern => {
      if (pattern.test(JSON.stringify(data))) {
        score += 0.3;
      }
    });
    
    return Math.min(score, 1);
  }
}

export default SystemMonitor;