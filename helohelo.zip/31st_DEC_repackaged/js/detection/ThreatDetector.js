class ThreatDetector {
  constructor(systemMonitor) {
    this.systemMonitor = systemMonitor;
    this.signatures = new Map();
    this.initializeSignatures();
  }

  initializeSignatures() {
    this.addSignature('ransomware', /\.encrypt\(|\.decrypt\(/i);
    this.addSignature('shellcode', /\x90{5,}|\x00{5,}/);
    this.addSignature('injection', /document\.write\(|eval\(|new Function\(/i);
  }

  addSignature(type, pattern) {
    this.signatures.set(type, pattern);
  }

  analyze(data) {
    for (const [type, pattern] of this.signatures) {
      if (pattern.test(JSON.stringify(data))) {
        this.systemMonitor.notifyListeners({
          type: 'malware-detected',
          malwareType: type,
          timestamp: Date.now(),
          data
        });
      }
    }
  }
}

export default ThreatDetector;