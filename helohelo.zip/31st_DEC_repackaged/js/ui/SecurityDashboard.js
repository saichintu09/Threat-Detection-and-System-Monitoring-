class SecurityDashboard {
  constructor(container, systemMonitor, logger) {
    this.container = container;
    this.systemMonitor = systemMonitor;
    this.logger = logger;
    this.initialize();
  }

  initialize() {
    this.createDashboard();
    this.systemMonitor.addListener(event => this.handleEvent(event));
  }

  createDashboard() {
    this.container.innerHTML = `
      <div class="security-dashboard">
        <div class="threat-panel">
          <h2>Active Threats</h2>
          <div id="active-threats"></div>
        </div>
        <div class="log-panel">
          <h2>Security Logs</h2>
          <div id="security-logs"></div>
        </div>
      </div>
    `;
  }

  handleEvent(event) {
    this.logger.log(event);
    this.updateDashboard();
  }

  updateDashboard() {
    const threatPanel = document.getElementById('active-threats');
    const logPanel = document.getElementById('security-logs');

    // Update threats
    threatPanel.innerHTML = Array.from(this.systemMonitor.activeThreats)
      .map(threat => `
        <div class="threat-item ${threat.type}">
          <span class="threat-type">${threat.type}</span>
          <span class="threat-score">Score: ${threat.score.toFixed(2)}</span>
          <span class="threat-time">${new Date(threat.timestamp).toLocaleTimeString()}</span>
        </div>
      `)
      .join('');

    // Update logs
    logPanel.innerHTML = this.logger.getLogs()
      .slice(0, 10)
      .map(log => `
        <div class="log-item ${log.severity.toLowerCase()}">
          <span class="log-time">${new Date(log.timestamp).toLocaleTimeString()}</span>
          <span class="log-severity">${log.severity}</span>
          <span class="log-message">${JSON.stringify(log)}</span>
        </div>
      `)
      .join('');
  }
}

export default SecurityDashboard;