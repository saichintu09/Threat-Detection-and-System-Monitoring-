import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import http from 'http';
import { Server } from 'socket.io';

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// In-memory storage for traffic data
let trafficData = [];

// Create HTTP server and initialize WebSocket server
const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

// WebSocket connection handler
io.on('connection', (socket) => {
    console.log('A client connected:', socket.id);

    // Send existing traffic data on connection
    socket.emit('initialData', trafficData);

    // Handle disconnection
    socket.on('disconnect', () => {
        console.log('Client disconnected:', socket.id);
    });
});

// API endpoint to receive traffic data
app.post('/traffic', (req, res) => {
    const packet = req.body;

    if (packet) {
        trafficData.push(packet);
        console.log('Received packet:', packet);

        // Emit the packet to all connected WebSocket clients
        io.emit('newPacket', packet);

        res.status(200).send('Packet received');
    } else {
        res.status(400).send('Invalid packet data');
    }
});

// API endpoint to fetch traffic data
app.get('/traffic', (req, res) => {
    res.status(200).json(trafficData);
});

// Start the server
server.listen(PORT, () => {
    console.log(`Backend server is running on http://localhost:${PORT}`);
});
